# P0 — Profil de volume · instructions d'intégration

Le goulot documenté dans `CLAUDE.md` §4 est levé. Ce document décrit ce qui
a été ajouté, comment le brancher, et ce qui reste ouvert.

## Résultat vérifié par exécution

```
lsr-engine    typecheck 0 erreur ·  214 tests verts   (inchangé, zéro régression)
lsr-backtest  typecheck 0 erreur ·   88 tests verts   (39 existants + 49 nouveaux)
lsr-options   typecheck 0 erreur ·   51 tests verts   (39 existants + 12 pour P1.4)
```

**Critère de sortie P0 atteint.** Le test `p0_integration.test.ts` fait passer
un `SweepSetup` complet — construit depuis le fixture Parquet MBO réel — dans
`evaluateLsr()`, qui rend un verdict :

```
[P0] chaîne complète OK — verdict=REJECTED · VPOC=4999.75 · tier=2
     · distVpoc=0.0tk · atrTicks=0.00 · niveaux=3
```

Le verdict `REJECTED` n'est pas un échec : sur ce fixture de quelques
centaines d'événements, l'ATR n'a pas assez de barres et vaut `0` par
fail-closed, ce qui fait légitimement refuser F3. **Ce qui est testé, c'est
qu'un verdict ait pu être rendu** — avant ce module, `evaluateLsr()` ne
pouvait pas être appelé du tout.

## Fichiers ajoutés

```
packages/lsr-backtest/
├── src/vp/histogram.ts       VolumeHistogram · VPOC · zone de valeur · LVN
├── src/vp/indicators.ts      VwapTracker · AtrTracker · VpocMigrationTracker
├── src/vp/processor.ts       VolumeProfileProcessor · buildLevels · projections
├── tests/volumeprofile.test.ts    47 tests unitaires
└── tests/p0_integration.test.ts    2 tests d'intégration bout en bout

packages/lsr-options/          (ex-artefact 3)
├── src/o5Logger.ts           P1.4 · journaliseur O5 continu
└── test/o5Logger.test.ts     12 tests
```

`src/index.ts` du paquet backtest exporte les trois nouveaux modules.

## Champs désormais produits

Tous ceux que `CLAUDE.md` §4 listait comme « ❌ personne » :

| Champ | Produit par | Consommé par |
|---|---|---|
| `distanceToVpocTicks` | `toEngineProfileFields` | A2 |
| `coincidesWithVpoc` · `secondaryReference` | `toEngineProfileFields` | A5b, F8-restreint |
| `levelTier` · `secondaryTier` | `toEngineProfileFields` | L1 |
| `valueMigrationTicks` | `toEngineMarketFields` | R1 |
| `vwapSlopeTicksPerMin` | `toEngineMarketFields` | R1 |
| `atrTicks` · `atrFast` · `atrSlow` | `toEngineMarketFields` | F3, L3 |

## Câblage dans la boucle de replay

```ts
const flow    = new OrderFlowProcessor({ ...DEFAULT_PROCESSOR_CONFIG, symbol: 'MES' });
const profile = new VolumeProfileProcessor({ tickSize: 0.25 });

for (const ev of sortDeterministic(events)) {
  flow.onEvent(ev);
  profile.onEvent(ev);          // ◀ même flux, même contrat que flow

  if (sweepDetected(flow)) {
    const snap = profile.snapshot();
    const pf = toEngineProfileFields(snap, sweptLevelPrice, tickSize, 2);
    const mf = toEngineMarketFields(snap, FAIL_CLOSED_MIGRATION, FAIL_CLOSED_SLOPE);
    // → assembler SweepSetup + MarketState, puis evaluateLsr()
  }
}
```

**`rollSession()` est explicite, jamais déduit d'un timestamp.** Ce module ne
connaît pas le calendrier des séances ; c'est au harness de replay ou au
driver live de l'appeler. Un roll implicite basé sur l'heure aurait divergé
entre backtest et live.

## Décisions de conception à connaître

**Seules les exécutions alimentent le profil.** `ADD`, `CANCEL` et `MODIFY`
décrivent des intentions, pas du volume échangé. Un profil construit sur les
ordres affichés mesurerait l'affichage, pas l'activité.

**L'ATR n'est pas réinitialisé au roll de séance.** La volatilité de fond ne
redémarre pas à zéro chaque matin, et F3/L3 en ont besoin dès la première
minute. Le profil volume-par-prix, lui, repart bien à zéro.

**Déterminisme garanti par départage explicite.** À volume égal, le VPOC
retient le prix le plus bas ; l'expansion de la zone de valeur étend vers le
bas. Ces choix sont arbitraires mais **fixes** : deux rejeux du même fichier
donnent le même profil. Un test le vérifie en inversant l'ordre d'insertion.

**Fail-closed sur tout.** Le snapshot renvoie `null` pour toute grandeur non
calculable ; ce sont les projections `toEngine*` qui décident de la valeur
faisant ÉCHOUER le gate — jamais une valeur neutre optimiste. Même discipline
que `toEngineOrderFlow` pour B1–B4.

| Grandeur absente | Valeur projetée | Effet |
|---|---|---|
| VPOC | `distanceToVpocTicks = 0` | A2 refuse (aucune place pour le TP) |
| Coïncidence | `false` | A5b refuse |
| Rang du niveau | `levelTier = 3` | L1 au plus exigeant |
| ATR | `0` | F3 et L3 refusent |
| Migration / pente | valeur fail-closed fournie par l'appelant | R1 refuse |

## Un bug attrapé pendant l'écriture

Le premier test d'intégration a échoué sur `state.rejectedSetupIds.includes`
— mon `LsrRuntimeState` de test utilisait un cast `as LsrRuntimeState` qui
masquait deux champs obligatoires. Le cast a été retiré au profit du type
complet : l'erreur est ainsi détectée à la compilation, pas à l'exécution.
Signalé plutôt que corrigé en silence.

## P1.4 — journaliseur O5 continu

Livré en parallèle, sans dépendance à P0. Échantillonne le kurtosis **à
intervalle fixe** plutôt qu'aux armements : à 0,4–0,8 trade/jour, attendre
les armements donnerait une poignée de points en cinq mois, quand
l'échantillonnage continu produit des centaines de mesures par séance.

Objectif : **calibrer le seuil de kurtosis sur de l'ES intraday réel**. Le
seuil 9 de D4 provient de rendements quotidiens FX et ne s'y transfère pas —
le kurtosis dépend fortement de la fréquence d'échantillonnage.

Journalise aussi `duplicatesRejected` et `outOfOrderRejected` : utile pour
mesurer la qualité réelle du feed après reconnexion.

## Ce qui reste ouvert

**Paramètres non calibrés** — tous marqués dans `DEFAULT_VP_CONFIG` :
`valueAreaCoverage` (0.70 est une convention, pas une mesure),
`lvnThresholdRatio`, `coincidenceToleranceTicks`, `minProfileVolume`,
périodes ATR. À réviser sur données réelles.

**Détection de sweep.** `sweepDetected(flow)` reste à écrire — c'est
l'`OrderFlowProcessor` qui la porte, pas le profil. Elle conditionne
l'appel de tout ce qui précède.

**Le fixture est petit.** Quelques centaines d'événements : suffisant pour
prouver que la chaîne s'exécute, insuffisant pour juger de la qualité des
niveaux produits. La validation réelle demande les ≥ 3 mois de MBO prévus
en P2.

**Prérequis inchangés.** La règle microscalping MFFU (ET ou OU) reste à
confirmer — si c'est un OU, la bascule en `WIDE_TP` change le R:R et le
seuil d'équilibre passe à 29 %. Cela ne modifie pas ce module, mais change
ce que les gates de sélectivité servent à protéger.
