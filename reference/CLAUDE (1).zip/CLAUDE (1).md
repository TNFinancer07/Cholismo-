# CLAUDE.md — Cholismo · LSR v1.7

> Fichier lu à chaque session. Il contient ce qui ne doit **jamais** être redécouvert
> ni réinventé. En cas de contradiction avec un autre document, **ce fichier gagne**.

> **Voir aussi `COMMANDS.md`** — matrice des slash commandes et règles de pilotage.
> Ce fichier-ci reste prioritaire sur `COMMANDS.md` en cas de contradiction.

---

## 1. Ce qu'est le projet

Stratégie **LSR (Liquidity Sweep Reversion)** : mean reversion après balayage de
liquidité, sur micro-futures indices (MES/MNQ), fenêtre 09:30–11:30 ET, pour
passer un challenge prop firm **MyFundedFutures Pro 50K**.

Le pari est un **R:R négatif** : risquer ~100 $ pour en gagner ~50 $, compensé
par un taux de réussite élevé. Seuil d'équilibre **66,7 %**, objectif **80 %** —
soit **13 points de marge**. Tout le système existe pour défendre ces 13 points.

**Le taux de réussite réel est INCONNU.** Aucun des 30 contrôles n'a été validé
sur données. Ils ont été choisis par raisonnement. La calibration sur 60 trades
doit **mesurer**, jamais confirmer. Ne jamais écrire dans le code ou la doc que
la stratégie « fonctionne » ou « a un edge ».

---

## 2. Invariants d'architecture — non négociables

Ces règles ont été établies après plusieurs corrections coûteuses. Les enfreindre
casse des propriétés du système qui ne sont pas toujours couvertes par un test.

1. **Fonctions pures, état injecté.** Le moteur ne lit ni `Date.now()` ni un
   état global. `now` et `runtimeState` sont des paramètres. C'est ce qui rend le
   backtest rejouable à l'identique.
2. **Fail-closed partout.** Donnée manquante, `NaN`, mesure impossible → **refus**.
   Une seule exception documentée : `R2` (divergence inter-indices) est neutre si
   la donnée corrélée est absente, sinon un feed manquant supprimerait la stratégie.
   Mais si la donnée est présente et corrompue, R2 bloque.
3. **Rejet plutôt que troncature silencieuse.** Si le sizing sort de la bande
   80–140 $, on **refuse le trade**. On ne prend jamais une taille réduite : un
   plan modifié en douce n'est plus le plan validé.
4. **Rien n'entrave une action de protection.** Le `STOP_LOSS` n'est jamais
   différé par M3. Une **annulation** n'est jamais bloquée par le gouverneur OTR
   (il n'existe aucune fonction `canCancel()`). On freine les *envois*, jamais
   les sorties.
5. **Aucun signal spontané.** Le moteur ne génère jamais d'ordre de lui-même —
   ni pour « faire acte de présence » (M4 est une **alerte seule**), ni autrement.
6. **Process et résultat jamais fusionnés.** Le score de résultat est masqué
   avant 20 trades. Le volet process est visible immédiatement.
7. **Fail-fast ordonné.** Le moteur s'arrête au premier refus. Pour l'analyse,
   `diagnoseAllGates()` évalue tout, **hors chemin chaud**.
8. **Tout seuil non calibré porte une étiquette `[CAL]`** dans `lsr.config.ts`.

---

## 3. État réel du code

| Paquet | Contenu | Tests |
|---|---|---|
| `packages/lsr-engine` | Moteur de décision TS (30 contrôles) | **214 ✓** |
| `packages/lsr-backtest` | Ingestion Parquet MBO + processeur order flow | **39 ✓** |
| `packages/cholismo-terminal` | Modules JS (core, backtest, rendu) + terminal HTML | manuel |

```bash
cd packages/lsr-engine   && npm install && npm run typecheck && npm test   # 214
cd packages/lsr-backtest && npm install && npm run typecheck && npm test   #  39
```

TypeScript en `strict` + `noUncheckedIndexedAccess`. **0 erreur attendue.**
Si le typecheck échoue, c'est une régression — ne pas contourner avec `any`.

### Le terminal
`packages/cholismo-terminal/terminal.html` — 6 onglets, **fichier autonome**
(double-clic). Les moteurs y sont **inlinés** parce que les modules ES sont
bloqués par CORS en `file://`. L'arborescence `src/` est la même logique, pour
intégration via serveur ou bundler. **Si tu modifies un moteur, modifie les deux**
ou documente lequel fait autorité.

---

## 4. ⚠ LE GOULOT — à traiter avant tout le reste

**Le module de profil de volume n'existe pas.** Le moteur consomme des champs
que **personne ne calcule** :

| Champ | Utilisé par |
|---|---|
| `distanceToVpocTicks` | A2 (TP borné) |
| `coincidesWithVpoc`, `secondaryReference` | A5b, F8-restreint |
| `levelTier`, `secondaryTier` | L1 (hiérarchie des niveaux) |
| `valueMigrationTicks`, `vwapSlopeTicksPerMin` | R1 (jour de tendance) |
| `atrTicks`, `atrFast`, `atrSlow` | F3, L3 |

Sans lui, **ni le backtest ni le live** ne peuvent construire un `SweepSetup`.
Il doit être **identique en backtest et en live**, comme `OrderFlowProcessor`.

Ordre recommandé : profil de volume → matching engine → harness de replay →
comptabilité prop firm → driver runtime. Le bandeau de session UI est
indépendant et parallélisable.

---

## 5. Pièges connus — déjà rencontrés, ne pas les réintroduire

**Sizing.** Le sizing VISE la cible 100 $ (`round(100 / R_contrat)`), il ne vise
PAS le haut de bande. Viser 140 gonflait le risque de 38 % et réduisait la marge
de 12 à 8 pertes survivables.

**Plafond de contrats.** Le plafond MFFU est **5 équivalents-minis = 50 micros**
(ratio 10:1). L'interpréter comme « 5 contrats bruts » rend le sizing micro
inutilisable. Sur ES, la bande de R ne laisse qu'**1 seul contrat** → scale-out
mort. Rester sur les micros.

**Calendrier économique.** Un tableau vide est **ambigu** (« rien aujourd'hui »
ou « chargement échoué »). D'où `calendarStatus: LOADED | STALE | UNAVAILABLE`.
Sans ce champ, M1 est **fail-OPEN** — c'était un vrai bug.

**Monte-Carlo — trois erreurs classiques :**
- Bootstrap **i.i.d.** détruit le clustering des pertes → ruine optimiste.
  Utiliser le **bootstrap par blocs** (mesuré : DD95 650 $ en i.i.d. vs 750 $ en blocs).
- **Biais du survivant** : exclure les trajectoires ruinées des statistiques
  écarte par construction les pires drawdowns (mesuré : 1 350 $ vs 1 550 $ à WR 70 %).
  Toujours publier le chiffre **toutes trajectoires**.
- **F2 doit se réinitialiser à chaque séance.** Un compteur cumulé n'est pas une
  limite journalière et invente des ruptures impossibles.

**Séries synthétiques.** Ne jamais construire `i < wins ? gain : -loss` : ça
empile tous les gains puis toutes les pertes, créant une grappe géante que le
bootstrap par blocs échantillonne. J'ai produit une fois « 34 % de ruine à WR
80 % » par cette erreur — le vrai chiffre est **0 %**. Utiliser `synthSeries()`.

**Remplissage des ordres limites.** Un ordre limite n'est **pas rempli au simple
touché** : il entre en fin de file FIFO et n'est exécuté que quand le volume
devant lui est consommé. C'est le biais le plus coûteux d'un backtest de scalping.

**Convention de côté des trades.** `tradeSideMeaning` = **agresseur**, pas le
passif consommé. L'inverser retourne B2 et B3 **en silence**.

**Nomenclature des barrières.** F2 = perte max **journalière**. F8 = drawdown de
**campagne**. F1 est le méta-veto sur le **type de compte** — ce n'est pas une
barrière de perte.

---

## 6. À vérifier auprès de MFFU avant tout achat

Ces valeurs conditionnent tous les calculs en aval. Elles sont marquées
`⚠ À VÉRIFIER` dans `lsr.config.ts`.

- [ ] **Buffer de drawdown** : 1 500 $ ou 2 000 $ ? (sources publiques divergentes ;
      change la marge de 8 à 11 pertes)
- [ ] Objectif d'évaluation (3 000 $ supposé)
- [ ] Plafond de contrats — **en équivalent-mini**
- [ ] Fenêtre de blackout news (−5 min / +2 min supposé)
- [ ] Règle d'inactivité : existe-t-elle ? quel délai ?
- [ ] Règle microscalping : est-ce bien un **ET** (« < 15 s **ET** < 5 points ») ?
      Si c'est un **OU**, `HOLD_TIME` ne suffit plus et il faut passer en
      `WIDE_TP` — ce qui **change la stratégie** (R:R positif, seuil 29 %).
- [ ] Le trailing se fige-t-il au solde de départ (`lockAtInitial`) ?

---

## 7. Conventions de travail

- **Français** dans le code, les commentaires et la doc.
- Commentaires qui expliquent le **pourquoi**, pas le quoi. Les décisions
  contre-intuitives doivent porter leur justification.
- Design system : `--bg-app:#0B0F15`, `--blue:#4E8FD0`, `--gold:#C9A24D`,
  `--rust:#C4685E`, Inter (UI) + JetBrains Mono (**tous** les chiffres).
- Jamais de couleur seule pour encoder un risque : forme + icône + couleur.
- Vérifier numériquement avant d'affirmer. Si un chiffre apparaît dans une doc,
  il doit venir d'une exécution, pas d'une estimation.
- Ne jamais corriger en silence : signaler l'écart et documenter la source.

---

## 8. Fréquence — la contrainte qui gouverne le planning

Avec les 30 contrôles actifs : **0,4 à 0,8 trade/jour**, soit ~100 séances
(**5 mois**) pour accumuler 60 trades de calibration.

Conséquence : **activer les contrôles par vagues**, avec 20 trades de mesure
entre chaque. Si le taux de réussite bouge alors que neuf changements sont
actifs, il sera **impossible** de savoir lequel a agi.

C'est la tension centrale du projet : chaque filtre améliore le taux de réussite
théorique et ralentit la capacité à vérifier s'il fonctionne.
