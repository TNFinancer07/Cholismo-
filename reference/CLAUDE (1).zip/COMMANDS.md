# ⚡ COMMANDS.md — Matrice de pilotage · Terminal Cholismo V2

> **Ce fichier ne remplace pas `CLAUDE.md`.** Il le complète.
> `CLAUDE.md` contient les invariants d'architecture, les pièges déjà payés et
> la checklist MFFU — en cas de contradiction, **`CLAUDE.md` gagne**, y compris
> contre ce document.

---

## 🛠️ Matrice des commandes

| Commande | Action | État |
|---|---|---|
| `/status` | Avancement par phase (P0–P5), tests verts, bilan typecheck | ✅ exécutable |
| `/next` | Déclenche le prochain jalon selon l'ordre de dépendance strict | ✅ exécutable |
| `/test-suite` | Suites complètes des 3 paquets + typecheck strict (0 erreur attendu) | ✅ exécutable |
| `/gate-check [O1–O5]` | Tests ciblés sur une balise du Pont Options v2 | ⚠️ voir note |
| `/sync-ui` | Alignement backend WebSocket/Redis ↔ composants v17 | ⛔ P4 requis |
| `/build-replay` | Compile et lance le harness de rejeu MBO | ⛔ P1 requis |
| `/log-o5` | Extrait de journalisation continue du kurtosis sur barres ES | ✅ exécutable |
| `/feature [nom]` | Nouveau module : pattern immuable + typage strict + tests | ✅ exécutable |
| `/devil` | Avocat du diable : cas limites, latence, pannes API, fuites | ✅ exécutable |
| `/debug [composant]` | Logs, données aberrantes, isolement de cause racine | ✅ exécutable |
| `/polish` | Refactor à comportement constant : imports, lisibilité, couverture | ✅ exécutable |

**Note `/gate-check`** — O1, O2, O3 et O5 sont testables aujourd'hui.
**O4 renverra toujours `O4_SOURCE_UNCONFIRMED`** tant que le Net Premium
Drift SPY/SPX n'est pas confirmé : la capture fournisseur le badge « QQQ
only ». Ce n'est pas un bug à corriger, c'est un prérequis externe non résolu.

**Commandes bloquées** — `/sync-ui` et `/build-replay` dépendent de phases non
livrées. Les appeler avant produirait un résultat vide ou trompeur ; elles
répondront en indiquant le jalon manquant plutôt qu'en simulant un succès.

---

## 📐 Règles d'ingénierie

### 1. Fail-closed par défaut
Tout composant à information insuffisante émet `REJECTED` / `FAIL` sans
interrompre le thread principal. Une valeur absente ne devient jamais une
valeur neutre optimiste : elle prend la valeur qui **fait échouer** le gate
concerné.

*Exception unique et documentée* : `R2` (divergence inter-indices) est neutre
si la donnée corrélée est absente — sinon un feed manquant supprimerait la
stratégie entière. Mais si la donnée est présente et corrompue, R2 bloque.

### 2. Mode consultatif G2
O1–O5 évaluent et journalisent sans bloquer l'exécuteur tant que la
calibration 60+ trades n'est pas scellée.

**Garantie structurelle, pas configuration** : aucun évaluateur de gate ne
retourne de booléen et aucun ne lève. Il n'existe nulle part un motif
`if (!gate) return null` désactivé qu'un refactor pourrait réactiver par
accident. La chaîne fail-fast conserve exactement **30 contrôles bloquants**.

### 3. Zéro code fictif — définition précise
Aucun module livré ne doit être un stub non câblé qui feint de fonctionner.

**Ce que cette règle n'interdit pas**, et qui doit rester possible :
- Les **doubles de test** (`MockVendorClient`) derrière une interface
  explicite — c'est ce qui permet de tester la mécanique sans abonnement
  fournisseur, et le remplacer ne touche à rien d'autre.
- Les **fixtures déterministes** (séries synthétiques à seed fixe) — sans
  elles, les tests deviennent non reproductibles.
- Les seuils **`PLACEHOLDER`** marqués comme tels — un seuil non calibré
  déclaré est plus honnête qu'un seuil inventé qui paraît validé.

Le critère : *un lecteur peut-il confondre ceci avec du code de production
validé ?* Si oui, c'est du code fictif. Sinon, c'est de l'outillage.

### 4. Conservation de l'IHM v17
Design, thème sombre et layout de `cholismo_lsr_terminal_v17.html` conservés
à 100 %.

**Précision nécessaire** : ce fichier est aujourd'hui une **maquette** — prix,
carnet et tape sont générés par `Math.random()` dans un bloc explicitement
commenté `PRIX SIMULÉ`. « Conserver l'IHM » signifie conserver le **design**
tout en **remplaçant ces générateurs** par des flux réels (P4). Les deux ne
s'opposent pas, mais confondre l'un et l'autre ferait livrer une maquette
comme un produit.

---

## 🔢 Numérotation des phases

Celle de la roadmap opérationnelle en cours, à ne pas confondre avec un
découpage antérieur qui décalait les numéros d'un cran :

| Phase | Contenu | État |
|---|---|---|
| **P0** | Profil de volume · ingestion MBO · journaliseur O5 | ✅ livré |
| **P1** | `sweepDetected` · Replay Engine · validation sur 3 mois MBO | ⬜ suivant |
| **P2** | Pont Options : Redis, O1–O4 temps réel, journal 60+ setups | ⬜ |
| **P3** | Simulateur d'exécution FIFO · Monte-Carlo sans biais du survivant | ⬜ |
| **P4** | Passerelle WebSocket · intégration UI v17 | ⬜ |
| **P5** | Pilote Rithmic · fail-safe · basculement sur panne | ⬜ |

### ⚠️ Point de séquencement non tranché — P2 avant P3

P2 prévoit de journaliser 60+ setups, mais le simulateur d'exécution FIFO
n'arrive qu'en P3. **Sans lui, aucun trade n'a de résultat** — or la question
de calibration est précisément : *les setups marqués FLAG ont-ils un taux de
réussite dégradé ?* On collecterait 60 verdicts sans rien à quoi les corréler.

Aggravant : le remplissage FIFO est ce que `CLAUDE.md` §5 désigne comme « le
biais le plus coûteux d'un backtest de scalping ». Un TP à 5 ticks rempli au
simple touché fabrique un taux de réussite inexistant — les résultats
obtenus avant P3 seraient donc **faux**, pas seulement absents.

**Recommandation : intervertir P2 et P3.** Décision non prise à ce jour.

### Correction de nomenclature
**O3 = obstacle géométrique** (aucun mur d'options entre l'entrée et le TP),
et non « persistance ». La persistance était la question posée par la surface
gamma dans les captures fournisseur — elle n'a pas été retenue comme gate.

---

## 🚫 Ce qu'aucune commande ne fera

- Écrire dans le code ou la documentation que la stratégie « fonctionne » ou
  « a un edge ». Le taux de réussite réel est **inconnu** : aucun des 30
  contrôles n'a été validé sur données, ils ont été choisis par raisonnement.
  La calibration doit **mesurer**, jamais confirmer.
- Contourner un échec de typecheck avec `any`. Un typecheck rouge est une
  régression.
- Corriger un écart en silence. Tout écart constaté est signalé et documenté
  avec sa source.
- Affirmer un chiffre sans exécution. Si un nombre apparaît dans une doc, il
  vient d'un run, pas d'une estimation.
